# Credentials
aws_access_key_id = "AKIAQGOWDODFP7S4CA4T"
aws_secret_access_key = "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"
region_name = "us-east-1"

# S3
bucket = "a2-13032022"
aws_url = "https://a2-13032022.s3.amazonaws.com/"
s3_key_url = "https://a2-13032022.s3.amazonaws.com/images/"
