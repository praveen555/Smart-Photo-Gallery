#!/bin/sh

python3 /home/ubuntu/A3/run.py